export const SERVER_PORT = process.env.SERVER_PORT || 5000;
export const CLIENT_PORT = process.env.CLIENT_PORT || 9000;
