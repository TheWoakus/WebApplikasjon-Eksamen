import mongoose from 'mongoose';
import slugify from 'slugify';

const { Schema } = mongoose;

const PollSchema = new Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
      min: ['1', 'Must at least contain 1 character'],
      max: ['24', 'Keep it simple'],
    },
    slug: {
      type: String,
    },
    description: {
      type: String,
      required: true,
    },
    question: {
      type: String,
      required: true,
    },
    option_1: {
      type: String,
      required: true,
    },
    option_2: {
      type: String,
      required: true,
    },
    option_3: {
      type: String,
      required: true,
    },
    option_4: {
      type: String,
      required: true,
    },
    result_1: {
      type: Number,
      reqired: true,
    },
    result_2: {
      type: Number,
      reqired: true,
    },
    result_3: {
      type: Number,
      reqired: true,
    },
    result_4: {
      type: Number,
      reqired: true,
    },
    user: {
      type: mongoose.Schema.ObjectId,
      ref: 'User',
      // required: true, -----> gives the following error: validation failed: user: Path `user` is required
    },    
  },
  { timestamps: true, toJSON: { virtuals: true }, toObject: { virtuals: true } }
);

PollSchema.pre('save', function (next) {
  this.slug = slugify(this.title, { lower: true });
  next();
});

export default mongoose.model('Poll', PollSchema);
