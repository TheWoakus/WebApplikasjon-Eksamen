import React, { useEffect, useState } from 'react';
import SignupForm from '../components/SignupForm';


const Register = () => (
  <>
    <h2>Come join the dark side, we have cookies!</h2>
    <SignupForm />
  </>
);

export default Register;
