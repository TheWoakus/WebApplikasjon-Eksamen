import React from 'react';
import { Link } from 'react-router-dom';


class Enter extends React.Component {
  render() {
    return (
      <>
        <h2>Please push the button!</h2>
        <section>
          <Link className="link callout" to={`/register`}>{"Register"}</Link>
        </section>
      </>      
    )
  }
}

export default Enter;