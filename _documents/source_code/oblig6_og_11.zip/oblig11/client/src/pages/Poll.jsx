import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { get } from '../utils/pollService';

const Poll = () => {
  const [poll, setPoll] = useState(null);
  const [error, setError] = useState(null);
  const params = useParams();

  const [count_option_1, setCount_option_1] = useState(0);
  const [count_option_2, setCount_option_2] = useState(0);
  const [count_option_3, setCount_option_3] = useState(0);
  const [count_option_4, setCount_option_4] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      const { data, error } = await get(params.id);
      if (error) {
        setError(error);
      } else {
        setPoll(data);
      }
    };
    fetchData();
  }, []);

  const fetchPoll = () => {
    if (poll === null) {
      const message = <h2>Fetching data</h2>;
      return message;
    }
    else {
      const result = { ...poll };
      const output =
        <>
          <section id="thePoll">
            <h2>{result.title}</h2>
            <p>{result.description}</p>
            <h2>Question&#58;</h2>
            <h2>{result.question}?</h2>
            <h2>Your answer</h2>
            <button
              type="button"
              id="option"
              className="button link"
              onClick={() => (setCount_option_1(count_option_1 + 1))}
            >{result.option_1}</button>
            <button
              type="button"
              id="option"
              className="button link"
              onClick={() => (setCount_option_2(count_option_2 + 1))}
            >{result.option_2}</button>
            <button
              type="button"
              id="option"
              className="button link"
              onClick={() => (setCount_option_3(count_option_3 + 1))}
            >{result.option_3}</button>
            <button
              type="button"
              id="option"
              className="button link"
              onClick={() => (setCount_option_4(count_option_4 + 1))}
            >{result.option_4}</button>
          </section>
          <section id="results">
            <h2>The results&#58;</h2>
            <p className="result">{result.option_1}&#58; <span>{count_option_1}</span></p>
            <p className="result">{result.option_2}&#58; <span>{count_option_2}</span></p>
            <p className="result">{result.option_3}&#58; <span>{count_option_3}</span></p>
            <p className="result">{result.option_4}&#58; <span>{count_option_4}</span></p>
          </section>
        </>
      return output;
    }
  }

  return (
    <>
      {fetchPoll()}
    </>
  );
};

export default Poll;
