import React, { useEffect, useState } from 'react';
import CreatePoll from '../components/CreatePoll';


const User = () => (
  <>
    <CreatePoll />
  </>
);

export default User;
