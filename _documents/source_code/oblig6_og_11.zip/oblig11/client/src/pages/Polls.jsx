import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { list } from '../utils/pollService';

const Polls = () => {
  const [polls, setPolls] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      const { data, error } = await list();
      if (error) {
        setError(error);
      } else {
        setPolls(data);
      }
    };
    fetchData();
  }, []);

  return (
    <>
    <h2>Available polls</h2>
    
    <section id="polls">
      {polls && polls.map((poll) => (
        <section className="poll" key={poll._id}>
          <h2 className="pollTitle">{poll.title}</h2>
          <p className="pollDescription">{poll.description}</p>
          <Link className="link" to={`/polls/${poll._id}`}>{"take poll"}</Link>
        </section>
      ))}
    </section>
    </>
  );
};

export default Polls;
