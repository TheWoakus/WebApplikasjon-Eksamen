import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import NoMatch from '../components/NoMatch';

import Enter from '../pages/Enter';
import Poll from '../pages/Poll';
import Polls from '../pages/Polls';
import User from '../pages/User';
import Register from '../pages/Register';

import Nav from '../components/Nav'


const Routes = () => (
  
  <Router>
      <Nav />
      <Switch>
        <Route exact path="/">
          <Enter />
        </Route>
          <Route exact path="/polls/">
            <Polls />
          </Route>
        <Route exact path="/polls/">
          <Polls />
        </Route>        
        <Route exact path="/user/">
          <User />
        </Route>
        <Route exact path="/register/">
          <Register />
        </Route>
        <Route path="/polls/:id">
          <Poll />
        </Route>
        <Route path="*">
          <NoMatch />
        </Route>
      </Switch>
  </Router>
);

export default Routes;
