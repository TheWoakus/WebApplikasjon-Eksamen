import React from 'react';
import { ThemeProvider } from 'styled-components';
import { GlobalStyles } from './Global';


const theme = {
  colors: {
    default: '#272727',
    yellow: '#ffc600',
    blue: '#193549',
  }
}

const Theme = ({ children }) => (
  <>
    <GlobalStyles />
    <ThemeProvider theme={theme}>{children}</ThemeProvider>
  </>
);
export default Theme;