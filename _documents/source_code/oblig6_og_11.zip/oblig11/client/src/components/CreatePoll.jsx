import React from 'react';
import axios from 'axios';
import { withRouter} from 'react-router-dom';


class Form extends React.Component {

  constructor() {
    super();

    this.onChangeTitle = this.onChangeTitle.bind(this);
    this.onChangeDescription = this.onChangeDescription.bind(this);
    this.onChangeQuestion = this.onChangeQuestion.bind(this);
    this.onChangeOption_1 = this.onChangeOption_1.bind(this);
    this.onChangeOption_2 = this.onChangeOption_2.bind(this);
    this.onChangeOption_3 = this.onChangeOption_3.bind(this);
    this.onChangeOption_4 = this.onChangeOption_4.bind(this);
  }

  onChangeTitle(event) {
    this.setState({ name: event.target.value })
  }

  onChangeDescription(event) {
    this.setState({ description: event.target.value})
  }

  onChangeQuestion(event) {
    this.setState({ question: event.target.value })
  }

  onChangeOption_1(event) {
    this.setState({ option_1: event.target.value })
  }

  onChangeOption_2(event) {
    this.setState({ option_2: event.target.value })
  }

  onChangeOption_3(event) {
    this.setState({ option_3: event.target.value })
  }
  
  onChangeOption_4(event) {
    this.setState({ option_4: event.target.value })
  }

  onSubmit(event) {
    event.preventDefault()

    const pollDetails = {
      title: this.title.value,
      description: this.description.value,
      question: this.question.value,
      option_1: this.option_1.value,
      option_2: this.option_2.value,
      option_3: this.option_3.value,
      option_4: this.option_4.value,
      result_1: 0,
      result_2: 0,
      result_3: 0,
      result_4: 0
    };
    
    axios.post(`${process.env.BASE_URL}${process.env.API_VERSION}/polls`, pollDetails)
    .then((res) => {
      console.log(res.data)
      this.pollForm.reset();
      this.props.history.push('/polls');
    }).catch((error) => {
      console.log(error)
    });

  }
  render() {
    return (
      <>
        <h2 className="callout">Create a poll</h2>
        <form 
          ref={(input) => (this.pollForm = input)}
          onSubmit={(event) => this.onSubmit(event)}
        >
          <fieldset>
            <label htmlFor="title">Title</label>
            <input
              ref={(input) => (this.title = input)}
              type="text"
              name="title"
              className="input"
              placeholder="Title of poll"
              onChange={this.onChangeTitle}
            />

            <label htmlFor="description">Description</label>
            <textarea
              ref={(input) => (this.description = input)}
              name="description"
              cols="30" 
              rows="5"
              className="input"
              placeholder="Short description of poll.."
              onChange={this.onChangeDescription}
            ></textarea>

            <label htmlFor="question">Question&#58;</label>
            <input
              ref={(input) => (this.question = input)}
              type="text"
              name="question"
              className="input"
              placeholder="Question"
              onChange={this.onChangeQuestion}
            />            

            <label htmlFor="option_1">Option #1</label>
            <input
              ref={(input) => (this.option_1 = input)}
              type="text"
              name="option_1"
              className="input"
              placeholder="Option"
              onChange={this.onChangeOption_1}
            />

            <label htmlFor="option_2">Option #2</label>
            <input
              ref={(input) => (this.option_2 = input)}
              type="text"
              name="option_2"
              className="input"
              placeholder="Option"
              onChange={this.onChangeOption_2}
            />

            <label htmlFor="option_3">Option #3</label>
            <input
              ref={(input) => (this.option_3 = input)}
              type="text"
              name="option_3"
              className="input"
              placeholder="Option"
              onChange={this.onChangeOption_3}
            />

            <label htmlFor="option_4">Option #4</label>
            <input
              ref={(input) => (this.option_4 = input)}
              type="text"
              name="option_4"
              className="input"
              placeholder="Option"
              onChange={this.onChangeOption_4}
            />

            <button
              type="submit"
              className="button link"
            >Create</button>
          </fieldset>
        </form>
      </>
    )
  }
}

export default withRouter(Form);