import React from 'react';
import axios from 'axios';
import { withRouter } from 'react-router-dom';

class Form extends React.Component {

  constructor() {
    super();

    this.onChangeName = this.onChangeName.bind(this);
    this.onChangeMail = this.onChangeMail.bind(this);
    this.onChangeUsername = this.onChangeUsername.bind(this);
    this.onChangePassword = this.onChangePassword.bind(this);
  }

  onChangeName(event) {
    this.setState({ name: event.target.value })
  }

  onChangeMail(event) {
    this.setState({ mail: event.target.value })
  }
  
  onChangeUsername(event) {
    this.setState({ username: event.target.value })
  }
  
  onChangePassword(event) {
    this.setState({ password: event.target.value })
  }

  onSubmit(event) {
    event.preventDefault()

    const userDetails = {
      name: this.name.value,
      mail: this.mail.value,
      username: this.username.value,
      password: this.password.value
    };

    axios.post(`${process.env.BASE_URL}${process.env.API_VERSION}/register`, userDetails)
      .then((res) => {
        console.log(res.data)
        this.signupForm.reset();
        this.props.history.push('/user');
      }).catch((error) => {
        console.log(error)
      });
  }
  render() {
    return (
      <>
        <form
          ref={(input) => (this.signupForm = input)}
          onSubmit={(event) => this.onSubmit(event)}
        >
          <fieldset>
            <label htmlFor="name">Name&#58;</label>
            <input
              ref={(input) => (this.name = input)}
              type="text"
              name="name"
              className="input"
              placeholder="Please enter your name"
              onChange={this.onChangeName}
            />

            <label htmlFor="mail">Mail&#58;</label>
            <input
              ref={(input) => (this.mail = input)}
              type="text"
              name="mail"
              className="input"
              placeholder="Please enter your mail address"
              onChange={this.onChangeMail}
            />

            <label htmlFor="username">Username&#58;</label>
            <input
              ref={(input) => (this.username = input)}
              type="text"
              name="username"
              className="input"
              placeholder="Please enter desired username"
              onChange={this.onChangeUsername}
            />

            <label htmlFor="password">Password&#58;</label>
            <input
              ref={(input) => (this.password = input)}
              type="text"
              name="password"
              className="input"
              placeholder="Please enter desired password"
              onChange={this.onChangePassword}
            />
            <button
              type="submit"
              className="button link"
            >Register</button>
          </fieldset>
        </form>
      </>
    )
  }
}

export default withRouter(Form);