import React from 'react';
import UserAvatar from '../assets/svg/user.svg';

const Header = () => (
  <header>
    <h1 id="logo">{process.env.APP_NAME}</h1>
  </header>
);

export default Header;
