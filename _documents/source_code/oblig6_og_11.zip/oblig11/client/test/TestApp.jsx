import React from 'react'

export const App = () => {
  return (
    <div>
        <span>Hello World</span>
    </div>
  )
}
