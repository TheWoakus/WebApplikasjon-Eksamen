import React from 'react';
import Theme from './src/styles/TommysTheme';
import Routes from './src/routes/Routes';

import Header from './src/components/Header';

const App = () => (
  <>
  <Theme>
    <Header />
    <section id="container">
      <Routes />
    </section>
  </Theme>
  </>
);

export default App;
