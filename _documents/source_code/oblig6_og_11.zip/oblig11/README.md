## REQUIREMENTS

For at alt skal fungere så trenger vi følgende:

  M.E.R.N
  -------
  
  MongoDB : https://docs.mongodb.com/manual/installation/
  
  Express
  
  React
  
  Node

  -------
  npm install

  Etter at mongodb er satt opp, må det lages en database som heter oblig11 (all lowercase).
  
  Dette gjøres ved å: 
    - fyre opp mongo (last ned MongoDB Compass om du vil) 
    - skriv: use oblig11
    - du skal nå få en bekreftelse på at du bruker databasen oblig11
  
  Dessverre får du ikke se databasen før vi legger til en collection.. Fyr opp server og app, så fikser vi dette.


## SERVER

  run npm start

  Kjører på http://localhost:7777


## CLIENT

  run npm start

  Kjører på http://localhost:3000