import React from 'react';
import { render } from 'react-dom';
import App from './components/App.jsx';

import './assets/scss/style.scss';

const app = document.getElementById('app');

render(<App />, app);
