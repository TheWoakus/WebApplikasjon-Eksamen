import React from 'react';

class Search extends React.Component {
  search(event) {
    let keyword = event.target.value;
    this.props.search(keyword);
  }

  render() {
    return (
      <input
        type="text"
        className="searchbox"
        placeholder="Enter title, description or author to search for.. (TIP: create a new one first)"
        onChange={(e) => this.search(e)}
      />
    );
  }
}
export default Search;
