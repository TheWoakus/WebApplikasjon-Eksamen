import React from 'react';

const Header2 = () => (
  <h2>Completed Todos</h2>
);

export default Header2;
