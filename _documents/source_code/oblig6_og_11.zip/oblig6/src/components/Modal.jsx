import React from 'react';

class Modal extends React.Component {
  constructor() {
    super();

    this.state = {
      remaining: 50,
    }
  }

  // run this
  componentDidMount() {
    this.clickListener();
  }

  // when user clicks on x, close the modal
  closeModal() {
    const modal = document.getElementById('modal');
    modal.style.display = 'none';
  }

  // when the user clicks anywhere outside the modal, close it
  clickListener() {
    const modal = document.getElementById('modal');
    window.onclick = function (event) {
      if (event.target === modal) {
        modal.style.display = 'none';
      }
    };
  }

  createToDo(event) {
    event.preventDefault();
    const todoDetails = {
      title: this.title.value,
      description: this.description.value,
      author: this.author.value,
    };
    this.props.addToDo(todoDetails);
    this.todoform.reset();
    { this.closeModal() };
  }

  counter(event) {
    const maxCharacters = 50;
    let usedCharacters = event.target.value.length;
    let remainingCharacters = maxCharacters - usedCharacters;
    this.setState({remaining: remainingCharacters})
  }

  render() {
    return (
      <>
        <section id="modal">
          <section id="modalContent">
            <h2>
              New todo
              <span
                id="close"
                role="button"
                tabIndex="0"
                onClick={this.closeModal}
                onKeyPress={this.closeModal}
              >
                &times;
              </span>
            </h2>

            <form
              ref={(input) => (this.todoform = input)}
              className="todo-edit"
              onSubmit={(e) => this.createToDo(e)}
            >
              <fieldset>
                <section id="fieldset">
                  <section className="field">
                    <label htmlFor="newTodoTitle">Title</label>
                    <input
                      ref={(input) => (this.title = input)}
                      type="text"
                      name="newTodoTitle"
                      id="newTodoTitle"
                      className="input"
                      placeholder="Todotitle"
                      required
                    />
                  </section>

                  <section>
                    <label htmlFor="newTodoDescription">
                      Description
                      <span id="counter">({this.state.remaining} characters left)</span>
                    </label>
                    <input
                      ref={(input) => (this.description = input)}
                      type="text"
                      name="newTodoDescription"
                      id="newTodoDescription"
                      className="input"
                      placeholder="Type a description"
                      maxLength="50"
                      required
                      onChange={(e) => this.counter(e)}
                    />
                  </section>

                  <section>
                    <label htmlFor="newTodoAuthor">Author</label>
                    <input
                      ref={(input) => (this.author) = input}
                      type="text"
                      name="newTodoAuthor"
                      id="newTodoAuthor"
                      className="input"
                      placeholder="First Last"
                      required
                    />
                  </section>
                  <button
                    type="submit"
                    id="create"
                    onSubmit={(e) => this.createToDo(e)}
                  >
                    Create
                  </button>
                </section>
              </fieldset>
            </form>
          </section>
        </section>
      </>
    );
  }
}

export default Modal;
