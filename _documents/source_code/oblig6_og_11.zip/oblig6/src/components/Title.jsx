import React from 'react';

const Title = () => (
  <>
    <section />
    <section>
      <h1 id="title">
        <span className="top">Jippi!!</span>
        <span className="bottom">Ingen todos i dag!!</span>
      </h1>
    </section>
    <section />
  </>
);

export default Title;
