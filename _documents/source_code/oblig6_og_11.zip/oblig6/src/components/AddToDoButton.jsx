import React from 'react';

class AddToDoButton extends React.Component {

  showModal() {
    const modal = document.getElementById("modal");
    modal.style.display = "block";
  }

  render() {
    return (
      <button id="addTodos" type="button" onClick={this.showModal}>
        <span id="plus">+</span>
        <span id="todoWord">Todo</span>
      </button>
    );
  }
}

export default AddToDoButton;
