import React from 'react';

class CompletedToDo extends React.Component {
  render() {
    return (
      <>
        <section className="completedTodo">
          <p>{this.props.details.title}</p>
          <p>{this.props.details.author}</p>
          <p>{this.props.details.description}</p>
          <p>{this.props.details.date}</p>
        </section>
      </>
    )
  }
}

export default CompletedToDo;
