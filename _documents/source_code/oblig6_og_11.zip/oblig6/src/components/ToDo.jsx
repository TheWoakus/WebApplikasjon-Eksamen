import React from 'react';

class ToDo extends React.Component {
  render() {
    return (
      <>
        <section className="todo">
          <h2 className="todoTitle">{this.props.details.title}</h2>
          <p className="todoDescription">{this.props.details.description}</p>
          <section className="buttons">
            <button
              type="button"
              className="delete"
              onClick={() => this.props.deleteToDo(this.props.keyID)}
            >
              delete
            </button>
            <button type="button" className="complete" onClick={() => this.props.completeToDo(this.props.keyID)}>
              complete
            </button>
          </section>
        </section>
      </>
    )
  }
}

export default ToDo;
