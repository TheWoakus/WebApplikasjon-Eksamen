import React from 'react';

const Titlebar = () => (
  <section id="titlebar">
    <p className="title">title</p>
    <p className="author">author</p>
    <p className="description">Description</p>
    <p className="date">completed date</p>
  </section>
);

export default Titlebar;
