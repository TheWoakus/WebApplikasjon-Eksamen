import React from 'react';

import AddToDoButton from './AddToDoButton.jsx';
import CompletedToDo from './CompletedToDo.jsx';
import Header from './Header.jsx';
import Header2 from './Header2.jsx';
import Modal from './Modal.jsx';
import Search from './Search.jsx';
import Title from './Title.jsx';
import Titlebar from './Titlebar.jsx';
import ToDo from './ToDo.jsx';

import { sampleNewToDos } from '../assets/js/sampleNewToDos.js';
import { sampleCompletedToDos } from '../assets/js/SampleCompletedToDos.js';

class App extends React.Component {
  constructor() {
    super();

    this.loadSamples = this.loadSamples.bind(this);
    this.addToDo = this.addToDo.bind(this);
    this.completeToDo = this.completeToDo.bind(this);
    this.deleteToDo = this.deleteToDo.bind(this);
    this.search = this.search.bind(this);

    this.state = {
      newTodos: {},
      completedTodos: {},
      search: null,
    };
  }

  componentDidMount() {
    this.loadSamples();
  }

  loadSamples() {
    this.setState({
      newTodos: sampleNewToDos,
      completedTodos: sampleCompletedToDos,
    });
  }

  addToDo(todoDetails) {
    const newTodos = { ...this.state.newTodos };
    const timestamp = Date.now();
    newTodos[`todo${timestamp}`] = todoDetails;
    this.setState({ newTodos });
  }

  deleteToDo(key) {
    const newTodos = { ...this.state.newTodos };
    delete newTodos[key];
    this.setState({ newTodos });
  }

  completeToDo(key) {
    const completedTodos = { ...this.state.completedTodos };
    const newTodos = { ...this.state.newTodos };
    const timestamp = new Date();
    completedTodos[key] = newTodos[key];
    completedTodos[key].realDate = timestamp;
    let dd = timestamp.getDate();
    let mm = timestamp.getMonth() + 1;
    let yy = timestamp.getFullYear();
    if (dd < 10) {
      dd = "0" + dd;
    }
    if (mm < 10) {
      mm = "0" + mm;
    }
    yy = yy - 2000;
    const now = `${dd}.${mm}.${yy}`;
    completedTodos[key].date = now;
    
    this.setState({ completedTodos });
    this.deleteToDo(key);
  }

  generateNewToDos() {
    const length = Object.keys(this.state.newTodos);
    if (length.length > 0) {
      const newToDos = Object.keys(this.state.newTodos)
        .reverse()
        .map((key) => (
          <ToDo
            deleteToDo={this.deleteToDo}
            completeToDo={this.completeToDo}
            newTodos={this.state.newTodos}
            completedTodos={this.state.completedTodos}
            keyID={key}
            key={key}
            details={this.state.newTodos[key]}
          />
        ));
      return newToDos;
    }
    return <Title />;
  }

  // could not find a good way to use this when using .filter()
  generateCompletedToDos() {
    const completedToDos = Object.keys(this.state.completedTodos).map((key) => (
      <CompletedToDo key={key} details={this.state.completedTodos[key]} />
    ));
    return completedToDos;
  }

  search(keyword) {
    this.setState({ search: keyword });
  }

  render() {
    
    const completedToDos = Object.values(this.state.completedTodos)
      .filter((data) => {
        if (this.state.search == null) {
          return data;
        }
        if (
          data.title.toLowerCase().includes(this.state.search.toLowerCase()) ||
          data.description
            .toLowerCase()
            .includes(this.state.search.toLowerCase()) ||
          data.author
            .toLowerCase()
            .includes(this.state.search.toLowerCase())   
        ) {
          return data;
        }
      })
      .map((data) => (
        <section className="completedTodo">
          <p>{data.title}</p>
          <p>{data.author}</p>
          <p>{data.description}</p>
          <p>{data.date}</p>
        </section>
      ));

    return (
      <>
        <Header />
        <Modal addToDo={this.addToDo} />
        <section id="container">
          <section id="newTodos">
            <AddToDoButton />
            <section id="todos">{this.generateNewToDos()}</section>
          </section>
          <section id="completedTodos">
            <Header2 />
            <section id="todolist">
              <Search search={this.search} />
              <Titlebar />
              {/* {this.generateCompletedToDos()} // ended up with a different solution.. new solution gives key warning.. */}
              {completedToDos}
            </section>
          </section>
        </section>
      </>
    )
  }
}

export default App;