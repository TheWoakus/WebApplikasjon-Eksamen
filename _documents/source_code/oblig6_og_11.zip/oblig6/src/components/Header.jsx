import React from 'react';
import UserAvatar from '../assets/svg/user.svg';

const Header = () => (
  <header>
    <h1 id="logo">hiof</h1>
    <nav>
      <p>Hei, Gjest</p>
      <img id="user" src={UserAvatar} alt="Sign in button" />
    </nav>
  </header>
);

export default Header;
