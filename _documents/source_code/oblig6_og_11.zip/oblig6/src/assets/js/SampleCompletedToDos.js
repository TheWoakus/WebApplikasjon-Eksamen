export const sampleCompletedToDos = {
  completed1: {
    id: '0',
    title: 'Todotitle',
    description: "I'm baby sriracha hot chicken",
    author: 'Author Author',
    date: '22.08.20',
    realdate: new Date('2020-07-22'),
  },
  completed2: {
    id: '1',
    title: 'Todotitle',
    description: "I'm baby sriracha hot chicken",
    author: 'Author Author',
    date: '22.06.20',
    realdate: new Date('2020-05-22'),
  },
  completed3: {
    id: '2',
    title: 'Todotitle',
    description: "I'm baby sriracha hot chicken",
    author: 'Author Author',
    date: '22.07.20',
    realdate: new Date('2020-06-22'),
  },
};
