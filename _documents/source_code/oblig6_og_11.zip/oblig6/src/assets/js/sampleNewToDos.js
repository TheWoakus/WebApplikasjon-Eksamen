export const sampleNewToDos = {
  todo1: {
    id: 'one',
    title: 'Todotitle',
    description: "I'm baby sriracha hot chicken mixtape pabst organic air ...",
    author: 'Author Author',
  },
  todo2: {
    id: 'two',
    title: 'Todotitle',
    description: "I'm baby sriracha hot chicken mixtape pabst organic air ...",
    author: 'Author Author',
  },
  todo3: {
    id: 'three',
    title: 'Todotitle',
    description: "I'm baby sriracha hot chicken mixtape pabst organic air ...",
    author: 'Author Author',
  },
};
